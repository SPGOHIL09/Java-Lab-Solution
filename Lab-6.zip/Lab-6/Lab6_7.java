/**
 * Lab6_7
 */
class Vehicle{
    final int speedLimit = 90;
     void run(){
        System.out.println("A Vehicle is Running!!!");
    }
    
}
class Bike extends Vehicle{
    void run(){
        System.out.println("A Bike is Running!!!");
    }
}
public class Lab6_7 {

    public static void main(String[] args) {
        
    }
}
